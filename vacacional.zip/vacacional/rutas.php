<?php 
$bodyClass = 'rutas';
include "includes/head.php";
?>
<main>
    <div class="container">
        <h2 class="uppercase"><img src="images/rutaicon.svg" alt="RT">Rutas turísticas</h2>
        <section class="listRT">
        </section>
    </div>
</main>

<? include 'includes/imports.php'?>

</body>

</html>