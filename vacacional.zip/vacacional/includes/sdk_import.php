<?
if (file_exists("includes/bogota.php")) {
    include "../includes/bogota.php";
    
}else{
    include "../../includes/bogota.php";
}
?>